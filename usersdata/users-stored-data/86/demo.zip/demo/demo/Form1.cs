﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace demo
{
    public partial class Form1 : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=.;Initial Catalog=demo;Integrated Security=True");
        int id;
        public Form1()
        {
            InitializeComponent();
        }
        public void adddata()
        {
            connection.Open();
            String str = "INSERT INTO [user] (name,password,class) values('"+name.Text+ "','" + password.Text + "','" + comboBox1.SelectedItem + "')";
            SqlCommand sqlCommand = new SqlCommand(str, connection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("Data Inserted Successfully!!");
            connection.Close();
        }
        public void display()
        {
            String str = "SELECT * FROM [user]";
            SqlDataAdapter dt = new SqlDataAdapter(str, connection);
            DataTable data = new DataTable();
            dt.Fill(data);
            if(data.Rows.Count > 0)
            {
                dataGridView1.DataSource=data;
            }

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow viewRow = this.dataGridView1.Rows[e.RowIndex];
            id = Convert.ToInt32(viewRow.Cells[0].Value);
            name.Text = viewRow.Cells[1].Value.ToString();
            password.Text = viewRow.Cells[2].Value.ToString();
        }
        public void delete_data()
        {
            connection.Open();
            String str = "DELETE FROM [user] WHERE id=" + id;
            SqlCommand sqlCommand = new SqlCommand(str, connection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("Data Deleted Successfully!!");
            connection.Close();
        }
        public void update_data()
        {
            connection.Open();
            String str = "UPDATE [user] SET name='"+name.Text+"',password='"+password.Text+"' WHERE id=" + id;
            SqlCommand sqlCommand = new SqlCommand(str, connection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("Data Updated Successfully!!");
            connection.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            adddata();
            display();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            display();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            display();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            delete_data();
            display();

        }

        private void update_Click(object sender, EventArgs e)
        {
            update_data();
            display();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
