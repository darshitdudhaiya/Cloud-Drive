﻿namespace CRUD_cSharp
{
    public class Form1Base
    {
    }
}