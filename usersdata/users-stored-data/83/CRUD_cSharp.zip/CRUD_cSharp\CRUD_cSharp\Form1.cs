﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_cSharp
{
    public partial class Form1 : Form
    {
        private SqlConnection con;
        

        public Form1()
        {
            InitializeComponent();
            Bingdata();
        }         
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-TF67O8D\\SQLEXPRESS;Initial Catalog=heet;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
      
        
        //----insert
  
        private void insert_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && comboBox1.Text != "")
            {
                conn.Open();
                SqlCommand command = new SqlCommand("insert into productinfo_tab values ('" + int.Parse(textBox1.Text) + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "', getdate())", conn);
                command.ExecuteNonQuery();
                MessageBox.Show("succsessfull inserted ");
                conn.Close();
                Bingdata();
            }
            else
            {
                MessageBox.Show("please put all data");
            }
        }
        void Bingdata()
        {
            SqlCommand command = new SqlCommand("select * from productinfo_tab ", conn);
            SqlDataAdapter sd = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        //----update
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "" && textBox3.Text != "" && comboBox1.Text != "")
            {
                conn.Open();
                SqlCommand command = new SqlCommand("update productinfo_tab set ItemName = '" + textBox2.Text + "',Design = '" + textBox3.Text + "' ,Color = '" + comboBox1.Text + "' where productID = '" + int.Parse(textBox1.Text) + "'", conn);
                command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("succsessfully upeted");
                Bingdata();
            }
            else
            {
                MessageBox.Show("please put All deteils");
            }
        }

        //----delete
        private void button2_Click(object sender, EventArgs e)
        {
            
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != "")
            {
                if (MessageBox.Show("Are you sure to delete", "delete record", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    conn.Open();
                    SqlCommand command = new SqlCommand("delete productinfo_tab where productID = '" + int.Parse(textBox5.Text) + "'", conn);
                    command.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("data delete succsessfully");
                    Bingdata();
                }
            }
            else
            {
                MessageBox.Show("please put productID");
            }
        }
        private void search_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != "")
            {
                SqlCommand command = new SqlCommand("select * from productinfo_tab where productID = '" + int.Parse(textBox4.Text) + "'", conn);
                SqlDataAdapter sd = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("enter product ID");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Product_Click(object sender, EventArgs e)
        {

        }

        private void ItemName_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseHover(object sender, EventArgs e)
        {

        }

        private void demo_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

   
    }
}
