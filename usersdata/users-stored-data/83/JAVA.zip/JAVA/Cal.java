class Cal
{
	public static void main(String arg[])
	{
		int a=Integer.parseInt(arg[0]);
		int b=Integer.parseInt(arg[1]);

		System.out.println("Add:"+(a+b));	
		System.out.println("Sub:"+(a-b));
		System.out.println("Mul:"+(a*b));
		System.out.println("Div:"+(a/b));
	}
}