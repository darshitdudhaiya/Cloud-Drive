class first
{
	public static void main(String arg[])
	{
		System.out.println("Hiiiiiii!!!");	
	}
}