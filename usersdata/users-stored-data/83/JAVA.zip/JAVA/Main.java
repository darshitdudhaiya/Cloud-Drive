import java.util.Scanner;
import static java.lang.Math.*;
class Demo {
    int value1,value2;
    Demo()
    {
         value1 = 10;
         value2 = 20;
    }
    Demo(int a)
    {
        value1 = a;
    }
    public void display(){
        System.out.println("Value1 === "+value1);
        System.out.println("Value2 === "+value2);
    }
}
 class constructor
{
    int number;
    constructor(int no)
    {
        number=no;
    }
}
final class test
{
    test()
    {
        System.out.println("This is example of final class!! ");
    }
}
 class IIB{
{
	System.out.println("Calling Constructor...........!!");
}
{
	System.out.println("Constructor called...........!!");	
}
}
public class Main {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.println("[1]Calculater of number");
        System.out.println("[2]Factoriyal of number");
        System.out.println("[3]Patten");
        System.out.println("[4]Vowel or consonant");
        System.out.println("[5]Commend line argument Array");
        System.out.println("[6]Constructor overloading");
        System.out.println("[7]Constructor using object");
        System.out.println("[8]Final variable");
        System.out.println("[9]Final class");
        System.out.println("[10]Finalize method");
        System.out.println("[11]Fibonacci series");
        System.out.println("[12]Static Import");
        System.out.println("[13]IIB");

        System.out.print("\n");
        System.out.println("Enter your choice:");
        int choice = obj.nextInt();
        switch (choice)
        {
// =========================== Calculater of number ================================
            case 1:
            int no1 = 200;
            int no2 = 200;
            int no3 = 20;
            System.out.println("Addition of Number is :"+ (no1+no2+no3));
            System.out.println("Subscription of Number is :"+ (no1-no2-no3));
            System.out.println("Multiplication of Number is :"+ (no1*no2*no3));
            System.out.println("Division of Number is :"+ (no1/no2/no3));
            break;

// =========================== Factoriyal  number ==============================
            case 2:
            int i, factorial =1, number=5;
            for(i = 1; i<=number; i++)
            {
                factorial = factorial * i;
            }
            System.out.println("Factorial of number 5 is:: "+factorial);
            break;

// ===========================  Patten  ==============================
            case 3:
            int j;
            for (i=1;i<=5;i++)
            {
                for (j=1;j<=i;j++)
                {
                    System.out.print("*");
                }
                System.out.println();
            }
            break;
// ===========================  Vowel or consonant ==============================
            case 4:
            char ch = 'A';
            if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'  || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' )
            {
                System.out.println("Character " + ch + " is vowel");
            }
            else
            {
                System.out.println("Character" + ch + " is consonant");
            }
            break;

// ===========================  Commendline argument array==============================
            case 5:
            System.out.println(args[0]);
            break;
//================================== Constructor overloading ============================
            case 6:
            Demo d1 = new Demo();
            Demo d2 = new Demo(30);
            d1.display();
            break;

//==================================== Constructor using object =========================
            case 7:
            constructor c1 = new constructor(10);
            System.out.println("Number is: " + c1.number);
            break;

//============================= Final variable ==============================
            case 8:
            final int age = 19;
            System.out.println("Age is: " + age);
            break;

//================================== final class ===========================
            case 9:
            test t1 = new test();
            break;

//===================================== finalize method =====================

            case 10:
            String str = "Hello world!!";
            str = null;
            break;

//===================================== fibonacci series ================
            case 11:
            int n1=0,n2=1,n3,count=10;
            System.out.print(n1+"    "+n2);

            for(i=2;i<count;++i)
            {
                n3=n1+n2;
                System.out.print(" "+n3);
                n1=n2;
                n2=n3;
            }
            break;
	
// ================================= static import =============================
	case 12:
	int  a=20, b=3,c=22;
	System.out.println(sqrt(a));
	System.out.println(pow(a,b));	
	System.out.println(abs(c));
	break;
// ============================== IIB =============================
	case 13:
	IIB obj1 = new IIB();
	break;
            default:
                System.out.println("Enter correct choice!!");
        }

    }
}