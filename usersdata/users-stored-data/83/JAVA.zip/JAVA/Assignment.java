import java.util.Scanner;
import static java.lang.Math.*;
class Hierarchical{
    Hierarchical()
    {
        System.out.println("I am Hierarchical class.....!");
    }
}
class child1 extends Hierarchical{
    child1()
    {
        System.out.println("I am child-1 of Hierarchical.......!");
    }
}
class child2 extends Hierarchical{
    child2()
    {
        System.out.println("I am child-2 of Hierarchical.......!");
    }
}

class dconstructor{
    dconstructor()
    {
        System.out.println("Hii, I am default constructor...!");
    }
}
class overloading{
    int a,b,c;
    overloading(int x,int y)
    {
        a=x;
        b=y;
        System.out.println("Sum of 2 number is :" + (a+b));
    }
    overloading(int x,int y,int z)
    {
        a=x;
        b=y;
        c=z;
        System.out.println("Sum of 3 number is :" + (a+b+c));
    }
}
class superc{
    superc()
    {
        System.out.println("Hi,I am parent class invite using super keyword....");
    }
}
class superc2 extends superc{
    superc2()
    {
        super();
        System.out.println("Hi,I am child class....");
    }
}
class Parent {
    void show()
    {
        System.out.println("Parent's show()");
    }
}
class Child extends Parent {
    void show()
    {
        System.out.println("Child's show()");
    }
}
abstract class marvel{
    abstract void name();
}
class ironman extends marvel{
    void name()
    {
        System.out.println("I am Ironman from marvel.......");
    }
}
class OuterClass
{
    static int outer_x = 10;
    int outer_y = 20;
    private static int outer_private = 30;

    static class StaticNestedClass
    {
        void display()
        {
            System.out.println("outer_x = " + outer_x);
            System.out.println("outer_private = " + outer_private);
        }
    }
}
final class demo{
    demo(){
        System.out.println("I am final class........");
    }
}
public class Assignment {
    public static void main(String arg[])
    {
        Scanner obj = new Scanner(System.in);
        System.out.println("[1]Hierarchical inheritance.");
        System.out.println("[2]Default constructor.");
        System.out.println("[3]Constructor overloading.");
        System.out.println("[4]Constructor using super keyword.");
        System.out.println("[5]Method overriding.");
        System.out.println("[6]Abstract class.");
        System.out.println("[7]Nested class.");
        System.out.println("[8]Static import.");
        System.out.println("[9]Final class.");
        System.out.println("[10]String method.");
        System.out.print("\n");
        System.out.println("Enter your choice:");
        int choice = obj.nextInt();
        switch (choice)
        {
// =========================== Hierarchical inheritance ================================
            case 1:
             child1 c1 = new child1();
             child2 c2 = new child2();
            break;
// ============================ Default constructor ===============================
            case 2:
            dconstructor d1 = new dconstructor();
            break;
// ============================ Constructor overloading ===========================
            case 3:
            overloading o1 = new overloading(10,30,50);
            break;
// ============================ constructor using super keyword ===================

            case 4:
            superc2 s1 = new superc2();
            break;

// ======================================== method overriding =======================

            case 5:
            Parent obj1 = new Parent();
            obj1.show();

            Parent obj2 = new Child();
            obj2.show();
            break;
// ======================================== abstract class =======================

            case 6:
            ironman name = new ironman();
            name.name();
            break;
// ======================================== nested class =======================

            case 7:
            OuterClass.StaticNestedClass nestedObject = new OuterClass.StaticNestedClass();
            nestedObject.display();
            break;
// ======================================== static import ========================

            case 8:
            int a=16,b=3,c=25;
            System.out.println(sqrt(a));
            System.out.println(pow(a,b));
            System.out.println(abs(c));
            break;
// =================================== final class ========================
            case 9:
            demo t1 = new demo();
            break;

            case 10:
            String name1 = new String("Jay");
            String str=name1.toUpperCase();
            System.out.println(str);
            break;
            default:

            {
                System.out.println("Enter correct choice.....!");
            }
        }
    }
}
