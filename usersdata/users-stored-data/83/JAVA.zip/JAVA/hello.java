package test;

public class hello  {
	public void hello()
	{
		System.out.println("Hello User!!");						
	}
}