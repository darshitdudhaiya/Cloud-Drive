import test.hello;
public class demo{
	public static void main(String arg[])
	{
		hello obj = new hello();
		obj.hello();
	}
}