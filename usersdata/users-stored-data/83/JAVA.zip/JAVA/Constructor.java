
class a
{
	
	a()
	{
		System.out.println("Calling A.................!");
	}
	
}
class b extends a
{	
	b()
	{
		super();
		System.out.println("Calling B.................!");
	}	
}
class Constructor
{
	public static void main (String args[])
	{

		b b1 =new b();
	}
}