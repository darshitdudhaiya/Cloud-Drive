import java.applet.*;
import java.awt.*;

/*<applet code="demo" height="400" width="400" backgroundcolor="red" color="red"></applet>*/

public class demo extends Applet{

	public void paint(Graphics g)
	{
		g.drawLine(100,100,400,400);
		g.setColor(Color.RED);	
		g.drawRect(100,100,300,300);
		g.drawLine(400,100,100,400);
	}

}