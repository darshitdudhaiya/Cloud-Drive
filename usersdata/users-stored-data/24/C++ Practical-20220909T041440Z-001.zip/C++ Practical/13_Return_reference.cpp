#include<iostream>

using namespace std;

int add(int *no,int *no1){

    int ans = *no + *no1;

    return ans;

}


int main()
{

    int num = 10;
    int num1 = 20;

    int ans = add(&num,&num1);

    cout << "Ans : " << ans << endl ;

    return 0;

}