#include<iostream>

using namespace std;

void add(int *no,int *no1){

    cout << "During : " << *no + *no1 << endl ;
}


int main()
{

    int num = 10;
    int num1 = 20;

    cout << "Before : " << num << endl ;
    cout << "Before : " << num1 << endl ;


    add(&num,&num1);

    cout << "After : " << num << endl ;
    cout << "After : " << num1 << endl ;

    return 0;

}