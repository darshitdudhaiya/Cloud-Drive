#include<iostream>

using namespace std;

int main()
{

    int no,no1,ans;

    cout << "Enter Number 1 : ";
    cin >> no;
    
    cout << "Enter Number 2 : ";
    cin >> no1;

    ans=no+no1;

    cout << "Total : " << ans;

    return 0;
}