#include <iostream>

using namespace std;

class person{

        private :
            string name;
            int age;

        public :
            void set_data(string name,int age);
            void show_data();

};


void person::set_data(string n,int a){

    name=n;
    age=a;

}

void person::show_data(){

    cout << "Entered Name : " <<  name << endl;
    cout << "Entered Age : " <<  age << endl;

}

int main()
{

    string n;
    int a;

    cout << "enter name : " << endl;
    cin >> n ;

    cout << "enter age : " << endl;
    cin >> a ;
    
    person p;

    p.set_data(n,a);
    p.show_data();  


    return 0;

}