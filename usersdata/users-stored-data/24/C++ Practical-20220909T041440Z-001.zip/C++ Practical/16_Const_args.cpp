#include<iostream>

using namespace std;

int add(int no1,const int no2 = 20,const int no3 = 10);

int main()
{
    int Ans;

    Ans = add(30);

    cout << Ans << endl;
    
    return 0;

}

int add(int no1,int no2,int no3)
{
    int ans = no1 + no2 + no3;
    return ans;
}