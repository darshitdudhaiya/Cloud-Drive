#include<iostream>

using namespace std;

int no = 10;

int main()
{

    int no = 20;

    cout << no << endl;
    cout << ::no << endl;


    return 0;
}