#include<iostream>
#include<iomanip>

using namespace std;

int main()
{

    //endl
    cout << "Hello" << endl;

    //setw
    cout <<  setw(10) << "Hello" << endl;

    //setpricision
    cout << setprecision(4) << 123.456 << endl;

    return 0;

}