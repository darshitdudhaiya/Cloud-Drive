#include<iostream>

using namespace std;

int add(int no1,int no2);

int main()
{
    int Ans;

    Ans = add(10,20);

    cout << Ans << endl;
    
    return 0;

}

int add(int no1,int no2)
{
    int ans = no1 + no2;
    return ans;
}