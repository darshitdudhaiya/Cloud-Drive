#include<iostream>

using namespace std;

int main()
{

    int no ;
    int &num = no;

    cout << "Enter number : " << endl ;
    cin >> no  ;
    cout << num  << endl;

    return 0;

}