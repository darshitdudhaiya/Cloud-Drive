#include<iostream>

using namespace std;

namespace math
{
    int add(int no1,int no2)
    {
        int ans = no1 + no2;
        return ans;
    }
}

int main()
{

    int Ans;

    Ans = math::add(20,30);

    cout << Ans << endl;

    return 0;

}