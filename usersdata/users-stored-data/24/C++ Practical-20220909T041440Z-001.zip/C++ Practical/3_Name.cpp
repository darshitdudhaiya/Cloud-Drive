#include<iostream>

using namespace std;

int main()
{

    char str[20];

    cout << "Enter your name : ";
    cin >> str;

    cout << "Your name is : " << str;

    return 0;
}