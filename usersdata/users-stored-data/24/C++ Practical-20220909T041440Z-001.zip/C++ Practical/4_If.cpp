#include<iostream>

using namespace std;

int main()
{
    
    int age;

    cout << "Enter Your Age : ";
    cin >> age;

    if(age>=18)
    {
        cout << "Congratulation!,Your are eligible to license.";
    }
    else
    {
        cout << "Sorry,Your are not eligible to license.";
    }

    return 0;
}